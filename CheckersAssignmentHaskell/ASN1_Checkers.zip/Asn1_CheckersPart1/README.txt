Minh Hang Chu
30074056
CPSC 449 - Fall 2019 - University of Calgary

Assignment 1: Checkers - English Draughts

Decription from Assignment website:

English draughts or checkers is described here it is played on an 8 x 8 checkered board starting with the "player" (who starts) having 12 black "men" at his end of the board and the "opponent" having 12 red "men" at his end.  The game is played on the "black" squares of the checkered board with alternating moves.  "Men" can only move diagonally forward.  When "men" are crowned -- achieved by reaching the other end of the board -- they become "kings".  "Kings" can move diagonally forward and backward.  A simple move is a single step diagonally by one piece (man or king) provided the position moved into is vacant.  A capture or jump move is when a player (resp. opponent) piece is diagonally adjacent to an opponent (resp. player) piece and the position diagonally behind the opponent (resp. player) piece is vacant: a jump move removes the opponent (resp. player) piece from the board (a capture) and occupies the vacant position behind the piece.  Both players must do a jump move if one is available.  Furthermore once a piece makes a jump it must completely exhaust all the jumps available to it: this may involve multiple jumps (which are allowed to change diagonal directions).

PLEASE NOTE: We are using a (Calgary) variant of the English rules which allows a pawn, which reaches the end row to become a king, to continue jumping (in the same turn) as a king ...

The objective of the game -- that is the winning conditions -- is to arrange that there is no move available to the opponent.  This can be achieved either by capuring all opponent pieces or by blocking every possible move that the opponent can make.  It is a draw if a state of the board is repeated ...

This folder has 2 other folders: Moves_MinhHangChu and Checkers_GUI

Moves_MinhHangChu folder consists of moves_tester.hs, moves.hs and GameStructures.hs to check if the program generate all the possible moves.
	Run test using cmd : stack ghci moves_tester.hs
	Then when we type cmd : main . Program will run and give out results of all tests cases.

Checkers_GUI contains a human - human version of Checkers Game.
	Run game using cmd : stack run
	A checker board will appear. Use space bar to choose the pieces and where it wants to move to. If it's an illegal move, player has to input again. Otherwise, switch turns.
	Game ends when there is no red pieces or black pieces on the board.