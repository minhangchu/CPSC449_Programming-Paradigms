
module Moves where

--import Lens.Micro.Platform -- DON'T!!!

import GameStructures


-------------ADD YOUR PROGRAM FOR MOVES-------------
--------------------BELOW HERE----------------------

dir :: GameState -> Int
dir st = case (_status st) of 
           Red -> -1
           Black -> 1

simple_moves:: GameState -> [Move]
simple_moves st
                | _status st == Red
                    = (simple_king_moves (_redKings st) st)++(simple_moves_pieces (_redPieces st) st)
                | _status st == Black
                    = (simple_king_moves (_blackKings st)st)++ (simple_moves_pieces (_blackPieces st)st)
                | otherwise = [] 

simple_moves_pieces :: [Coord] -> GameState -> [Move]
simple_moves_pieces coords g = [[(x,y), (x',y')] | (x,y) <- coords,
                                                   (x',y') <- [(x+1,y + (dir g)),(x-1,y + (dir g))],
                                    emptypositions (x',y') g,
                                    onboard (x',y')]

simple_king_moves :: [Coord] -> GameState -> [Move]
simple_king_moves coords g = [[(x,y), (x',y')] | (x,y) <- coords,
                                                 (x',y') <- [(x+1,y+1),(x-1,y+1), (x+1,y-1), (x-1,y-1)],
                                                 emptypositions (x',y') g,
                                                 onboard (x',y')]

jump_moves :: GameState -> [Move]
jump_moves st | _status st == Red
              = (jumpKing (_redKings st) st)++(jumpPawn (_redPieces st) st)
              | _status st == Black
              = (jumpKing (_blackKings st)st)++ (jumpPawn (_blackPieces st)st)
              | otherwise = [] 


jumpKing::[Coord]->GameState->[Move]
jumpKing xs st= [(x,y):ys | (x,y) <- xs, ys <- jumpKing' (x,y) [] (x,y) st]
 

jumpKing'::Coord->[Coord]->Coord->GameState->[Move]
jumpKing' start rem (x,y) st = [ (x'',y''):ys | ((x',y'),(x'',y'')) <- [((x+1,y+1),(x+2,y+2)),((x-1,y+1),(x-2,y+2)),((x+1,y-1),(x+2,y-2)),((x-1,y-1),(x-2,y-2))]
                               , (not (elem (x',y') rem)) && (opponent_occupied (x',y') st) && (start==(x'',y'') || (emptypositions (x'',y'') st && onboard (x'',y''))) 
                               , ys <- jump_over (jumpKing' start ((x',y'):rem) (x'',y'') st) ]
 
                               
-- if there is no more moves, then returns empty.
jump_over::[Move]->[Move]
jump_over []  = [[]]
jump_over z  = z

jumpPawn::[Coord]->GameState->[Move]
jumpPawn xs st= [(x,y):ys | (x,y) <- xs, ys <- jumpPawn' (x,y) [] (x,y) st]

jumpPawn'::Coord->[Coord]->Coord->GameState->[Move]
jumpPawn' start rem (x,y) st = [ (x'',y''):ys | ((x',y'),(x'',y'')) <- [((x+1,y+(dir st)),(x+2,y+2*(dir st))),((x-1,y+(dir st)),(x-2,y+2*(dir st)))]
                                , (not (elem (x',y') rem)) && (opponent_occupied (x',y') st) && (start==(x'',y'') || (emptypositions (x'',y'') st && onboard (x'',y'')))
                                , ys <- case (checkKing (x'',y'') st == True) of
                                  True -> jump_over (jumpKing' start ((x',y'):rem) (x'',y'') st)
                                  False -> jump_over (jumpPawn' start ((x',y'):rem) (x'',y'') st)]

opponent_occupied :: Coord -> GameState -> Bool
opponent_occupied (x,y) st | (_status st == Red) && (((x,y) `elem` (_blackPieces st) || (x,y) `elem` (_blackKings st))) = True
                           | (_status st == Black) && (((x,y) `elem` (_redPieces st) || (x,y) `elem` (_redPieces st))) = True
                           | otherwise = False

onboard :: Coord -> Bool
onboard (x,y) = if (0 <= x) && (x<=7) && (0 <= y) && (y <= 7) then True else False
 
emptypositions :: Coord -> GameState -> Bool
emptypositions (x,y) g
  | (x,y) `elem` (allPieces g) = False
  | otherwise = True
  where
    allPieces g = (_blackPieces g) ++ (_blackKings g) ++ (_redPieces g) ++ (_redKings g)


jumped :: Coord -> Coord -> Coord
jumped (x,y) (x',y') = ((x+x')`div`2,(y+y')`div`2)

checkKing:: Coord -> GameState -> Bool
checkKing (x,y) st
    | (_status st) == Red = if y == 0 then True else False
    | (_status st) == Black = if y == 7 then True else False 

changePlayer :: Status -> Status
changePlayer x | x == Black = Red
               | otherwise = Black

replace :: Eq a => a -> a -> [a] -> [a]
replace a b = map (\x -> if (a == x) then b else x)

delete :: (Eq a) => a -> [a] -> [a]
delete = deleteBy (==) where 
  deleteBy _  _ [] = []
  deleteBy eq x (y:ys) = if x `eq` y then ys else y : deleteBy eq x ys

moves :: GameState -> [Move]
moves st
  | jumpmoves /= [] = jumpmoves
  | otherwise = simplemoves
  where
    simplemoves = simple_moves st
    jumpmoves = jump_moves st
