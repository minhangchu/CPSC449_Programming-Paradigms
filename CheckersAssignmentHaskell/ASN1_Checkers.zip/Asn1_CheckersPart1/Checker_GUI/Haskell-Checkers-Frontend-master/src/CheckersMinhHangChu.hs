module CheckersMinhHangChu where

--import Tui
import Checkers

dir :: GameState -> Int
dir st = case (_status st) of 
           Red -> -1
           Black -> 1

simple_moves:: GameState -> [Move]
simple_moves st
                | _status st == Red
                    = (simple_king_moves (_redKings st) st)++(simple_moves_pieces (_redPieces st) st)
                | _status st == Black
                    = (simple_king_moves (_blackKings st)st)++ (simple_moves_pieces (_blackPieces st)st)
                | otherwise = [] 

simple_moves_pieces :: [Coord] -> GameState -> [Move]
simple_moves_pieces coords g = [[(x,y), (x',y')] | (x,y) <- coords,
                                                   (x',y') <- [(x+1,y + (dir g)),(x-1,y + (dir g))],
                                    emptypositions (x',y') g,
                                    onboard (x',y')]

simple_king_moves :: [Coord] -> GameState -> [Move]
simple_king_moves coords g = [[(x,y), (x',y')] | (x,y) <- coords,
                                                 (x',y') <- [(x+1,y+1),(x-1,y+1), (x+1,y-1), (x-1,y-1)],
                                                 emptypositions (x',y') g,
                                                 onboard (x',y')]


jump_moves :: GameState -> [Move]
jump_moves st | _status st == Red
              = (jumpKing (_redKings st) st)++(jumpPawn (_redPieces st) st)
              | _status st == Black
              = (jumpKing (_blackKings st)st)++ (jumpPawn (_blackPieces st)st)
              | otherwise = [] 



jumpKing::[Coord]->GameState->[Move]
jumpKing xs st= [(x,y):ys | (x,y) <- xs, ys <- jumpKing' (x,y) [] (x,y) st]
 

jumpKing'::Coord->[Coord]->Coord->GameState->[Move]
jumpKing' start rem (x,y) st = [ (x'',y''):ys | ((x',y'),(x'',y'')) <- [((x+1,y+1),(x+2,y+2)),((x-1,y+1),(x-2,y+2)),((x+1,y-1),(x+2,y-2)),((x-1,y-1),(x-2,y-2))]
                               , (not (elem (x',y') rem)) && (opponent_occupied (x',y') st) && (start==(x'',y'') || (emptypositions (x'',y'') st && onboard (x'',y''))) 
                               , ys <- jump_over (jumpKing' start ((x',y'):rem) (x'',y'') st) ]
 
                               
jump_over::[Move]->[Move]
jump_over []  = [[]]
jump_over z  = z

jumpPawn::[Coord]->GameState->[Move]
jumpPawn xs st= [(x,y):ys | (x,y) <- xs, ys <- jumpPawn' (x,y) [] (x,y) st]

jumpPawn'::Coord->[Coord]->Coord->GameState->[Move]
jumpPawn' start rem (x,y) st = [ (x'',y''):ys | ((x',y'),(x'',y'')) <- [((x+1,y+(dir st)),(x+2,y+2*(dir st))),((x-1,y+(dir st)),(x-2,y+2*(dir st)))]
                                , (not (elem (x',y') rem)) && (opponent_occupied (x',y') st) && (start==(x'',y'') || (emptypositions (x'',y'') st && onboard (x'',y'')))
                                , ys <- case (checkKing (x'',y'') st == True) of
                                  True -> jump_over (jumpKing' start ((x',y'):rem) (x'',y'') st)
                                  False -> jump_over (jumpPawn' start ((x',y'):rem) (x'',y'') st)]

opponent_occupied :: Coord -> GameState -> Bool
opponent_occupied (x,y) st | (_status st == Red) && (((x,y) `elem` (_blackPieces st) || (x,y) `elem` (_blackKings st))) = True
                           | (_status st == Black) && (((x,y) `elem` (_redPieces st) || (x,y) `elem` (_redPieces st))) = True
                           | otherwise = False

onboard :: Coord -> Bool
onboard (x,y) = if (0 <= x) && (x<=7) && (0 <= y) && (y <= 7) then True else False
 
emptypositions :: Coord -> GameState -> Bool
emptypositions (x,y) g
  | (x,y) `elem` (allPieces g) = False
  | otherwise = True
  where
    allPieces g = (_blackPieces g) ++ (_blackKings g) ++ (_redPieces g) ++ (_redKings g)

jumped :: Coord -> Coord -> Coord
jumped (x,y) (x',y') = ((x+x')`div`2,(y+y')`div`2)


make_simple_move :: Move -> GameState -> GameState
make_simple_move [start,end] st 
      | [start,end] `elem` simple_moves st && (_status st) == Red && (checkKing end st == True)  
        = st {_redKings = end : (_redKings st), _redPieces = delete start (_redPieces st),
        _status = changePlayer (_status st), _message = "Black turn!"}
      | [start,end] `elem` simple_moves st && (_status st) == Black && (checkKing end st== True)
        = st {_blackKings = end : (_blackKings st), _blackPieces = delete start (_blackPieces st),
        _status = changePlayer (_status st), _message = "Red turn!"}

      | start `elem` (_redKings st) && (_status st == Red)
        = st {_redKings = replace start end (_redKings st),
        _status = changePlayer (_status st), _message = "Black turn!"}
      | start `elem` (_blackKings st) && (_status st == Black)
        = st {_blackKings = replace start end (_blackKings st),
        _status = changePlayer (_status st), _message = "Red turn!"}
      | start `elem` (_blackPieces st) && (_status st == Black)
        = st {_blackPieces = replace start end (_blackPieces st),
        _status = changePlayer (_status st), _message = "Red turn!"}
      | elem start (_redPieces st) && (_status st == Red)
        = st {_redPieces = replace start end (_redPieces st),
        _status = changePlayer (_status st), _message = "Black turn!"}
      | otherwise = st {_message = "Try again!"}

make_jump_move :: Move -> GameState -> GameState    
make_jump_move [] st = st {_status = changePlayer (_status st) }  
make_jump_move (start:(next:rest)) st

       | _status st == Red && elem start (_redPieces st) && (checkKing next st == True)
        = make_jump_move (next:rest)
          (st{_blackKings = (delete (jumped start next)) (_blackKings st)
              ,_blackPieces = (delete (jumped start next)) (_blackPieces st)
              ,_redPieces = (delete start (_redPieces st))
              ,_redKings = next:(_redKings st)
              ,_message = "Black turn"})

       | _status st == Black && elem start (_blackPieces st) && (checkKing next st == True)
        = make_jump_move (next:rest)
          (st{_redKings = (delete (jumped start next)) (_redKings st)
              ,_redPieces = (delete (jumped start next)) (_redPieces st)
              ,_blackPieces = (delete start (_blackPieces st))
              ,_blackKings = next:(_blackKings st)
              ,_message = "Red turn"})

       | _status st == Red && elem start (_redKings st)
        = make_jump_move (next:rest)
          (st{_blackKings = delete (jumped start next) (_blackKings st)
              ,_blackPieces = delete (jumped start next) (_blackPieces st)
              ,_redKings = next:(delete start (_redKings st))
              ,_message = "Black turn"})
                               
       | _status st == Black && elem start (_blackKings st)
        = make_jump_move (next:rest)
          (st{_redKings = delete (jumped start next) (_redKings st)
              ,_redPieces = delete (jumped start next) (_redPieces st)
              ,_blackKings = next:(delete start (_blackKings st)) 
              ,_message = "Red turn"})

       | _status st == Red && elem start (_redPieces st)
        = make_jump_move (next:rest)
          (st{_blackKings = delete (jumped start next) (_blackKings st)
              ,_blackPieces = delete (jumped start next) (_blackPieces st)
              ,_redPieces = next:(delete start (_redPieces st))
              ,_message = "Black turn"})
                                                     
       | _status st == Black && elem start (_blackPieces st)
        = make_jump_move (next:rest)
          (st{_redKings = delete (jumped start next) (_redKings st)
              ,_redPieces = delete (jumped start next) (_redPieces st)
              ,_blackPieces = next:(delete start (_blackPieces st))
              ,_message = "Red turn"})

       | otherwise = st {_message = "jump!"}
make_jump_move _ st = st {_status = changePlayer (_status st) } 

checkKing:: Coord -> GameState -> Bool
checkKing (x,y) st
    | (_status st) == Red = if y == 0 then True else False
    | (_status st) == Black = if y == 7 then True else False 

changePlayer :: Status -> Status
changePlayer x | x == Black = Red
               | otherwise = Black

replace :: Eq a => a -> a -> [a] -> [a]
replace a b = map (\x -> if (a == x) then b else x)

delete :: (Eq a) => a -> [a] -> [a]
delete = deleteBy (==) where 
  deleteBy _  _ [] = []
  deleteBy eq x (y:ys) = if x `eq` y then ys else y : deleteBy eq x ys

moves :: GameState -> [Move]
moves st
  | jumpmoves /= [] = jumpmoves
  | otherwise = simplemoves
  where
    simplemoves = simple_moves st
    jumpmoves = jump_moves st

apply_move :: Move -> GameState -> GameState
apply_move mv st | ((_redKings st) == [] && (_redPieces st) == [])= st {_status = GameOver, _message = "Black WIN!"}
                 | (_blackPieces st == [] && _blackKings st ==[]) = st {_status = GameOver, _message = "RED WIN!"}
                 | elem mv (moves st) && (jump_moves st /= []) = make_jump_move mv st
                 | elem mv (moves st) && (jump_moves st == []) = make_simple_move mv st
                 | otherwise = st{_message = "Illegal move!!"}


--------------------------------------------------------------AI--------------------------------------------------------------------------------


black_heuristic:: GameState -> Int                     
black_heuristic st = length(_blackPieces st) - length(_redPieces st) + 2*(length(_blackKings st) - length(_redKings st))

red_heuristic::GameState -> Int
red_heuristic st =  length(_redPieces st) - length(_blackPieces st) + 2*(length(_redKings st) - length(_blackKings st))


minMaxBlack :: GameState -> Integer -> Bool -> Int
minMaxBlack st d tf 
    | d == 0  || moves st == [] = black_heuristic st
    | tf == False = minimum (map (\a -> minMaxBlack a (d-1) True) (allChildren st))
    | tf == True = maximum (map (\a -> minMaxBlack a (d-1) False) (allChildren st))
    | otherwise = -30000
    where 
        allChildren st = foldr (\x y -> (apply_move x st):y) [] (moves st)

scoreMoveBlack :: GameState -> [Move] -> Integer -> Bool -> [(Move, Int)]
scoreMoveBlack st [] _ _ = []
scoreMoveBlack st (m:ms) d tf = (m, minMaxBlack (apply_move m st) (d-1) False) : (scoreMoveBlack st ms d False)

sNum = -3000

blackAI_move :: [(Move, Int)] -> Move -> Int -> Move
blackAI_move [] m n = m
blackAI_move (x:xs) m n = if (snd x > n) then blackAI_move xs (fst x) (snd x) else blackAI_move xs m n

black_ai :: GameState -> Move
black_ai st = blackAI_move (scoreMoveBlack st (moves st) 4 True) [] sNum





minMaxRed :: GameState -> Integer -> Bool -> Int
minMaxRed st d tf 
    | d == 0 || moves st == [] = red_heuristic st 
    | tf == False = minimum (map (\a -> minMaxRed a (d-1) True) (allChildren st))
    | tf == True = maximum (map (\a -> minMaxRed a (d-1) False) (allChildren st))
    | otherwise = -30000
    where 
        allChildren st = foldr (\x y -> (apply_move x st):y) [] (moves st)

scoreMoveRed :: GameState -> [Move] -> Integer -> Bool -> [(Move, Int)]
scoreMoveRed st [] _ _ = []
scoreMoveRed st (m:ms) d tf = (m, minMaxRed (apply_move m st) (d-1) False) : (scoreMoveRed st ms d False)


redAI_move :: [(Move, Int)] -> Move -> Int -> Move
redAI_move [] m n = m
redAI_move (x:xs) m n = if (snd x > n) then redAI_move xs (fst x) (snd x) else redAI_move xs m n

red_ai :: GameState -> Move
red_ai st = redAI_move (scoreMoveRed st (moves st) 4 True) [] sNum

