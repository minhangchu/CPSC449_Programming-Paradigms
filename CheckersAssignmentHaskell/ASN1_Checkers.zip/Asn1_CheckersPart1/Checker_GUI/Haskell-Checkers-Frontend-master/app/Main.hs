module Main where

--import Tui
import Checkers
import CheckersMinhHangChu

 
main :: IO ()
main = human apply_move initialGameState


